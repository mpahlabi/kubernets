#!/bin/bash

# *******************************
# Creating Kubernetes HA Cluster
# *******************************

export CLUSTER_NAME=${CLUSTER_NAME:-"prodkube.thecoreai.com"}
export NODE_SIZE=${NODE_SIZE:-t2.micro}
export MASTER_SIZE=${MASTER_SIZE:-t2.micro}
export MASTER_ZONES=${MASTER_ZONES:-"us-west-2a"}
export ZONES=${ZONES:-"us-west-2a,us-west-2b"}
export KOPS_STATE_STORE="s3://kopscluster-19022020"

#./delete-kops-cluster.sh

kops create cluster \
  --name=${CLUSTER_NAME} \
  --state=${KOPS_STATE_STORE} \
  --authorization RBAC \
  --master-zones=${MASTER_ZONES} \
  --zones=${ZONES} \
  --node-count=2 \
  --node-size=${NODE_SIZE} \
  --master-size=${MASTER_SIZE} \
  --master-count=1 \
#  --image=ami-07b4f3c02c7f83d59 \
  --dns-zone=thecoreai.com \
  --cloud-labels="Team=DevOps,Environment=DEV" \
  --out=devkops_terraform \
  --target=terraform \
#  --kubernetes-version "1.11.0" \
#  --bastion \
#  --topology=private \
#  --networking=weave \
  --ssh-public-key=id_rsa.pub

#./pull-kubeconfig.sh
