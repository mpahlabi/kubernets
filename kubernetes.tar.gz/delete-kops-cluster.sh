#!/bin/bash

export KOPS_STATE_STORE="s3://kopscluster-19022020"

kops delete cluster \
  --name=prodkube.thecoreai.com \
  --yes \
  --state=${KOPS_STATE_STORE}
